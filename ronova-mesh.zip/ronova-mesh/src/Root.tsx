import React from 'react';
import {Composition} from 'remotion';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './config';
import {RonovaMeshPromo} from './RonovaMeshPromo';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="RonovaMeshPromo"
    component={RonovaMeshPromo}
    durationInFrames={DURATION_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
