import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {ProfileAvatar, Tone} from '../components/ProfileAvatar';
import {FriendRequestCard, ProfileCard} from '../components/Cards';
import {ConnectionLine, NetworkLayer} from '../components/Network';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, lerp, prog, settle} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';

const HUB = {x: 960, y: 540};
const RING1: Array<{x: number; y: number; tone: Tone}> = [0, 1, 2, 3, 4, 5].map((k) => {
  const a = ((k * 60 - 30) * Math.PI) / 180;
  return {x: HUB.x + Math.cos(a) * 460, y: HUB.y + Math.sin(a) * 270, tone: (['amber', 'orange', 'ink', 'amber', 'orange', 'ink'] as Tone[])[k]};
});
const RING2: Array<{x: number; y: number; tone: Tone}> = [0, 1, 2, 3].map((k) => {
  const a = ((k * 90 + 45) * Math.PI) / 180;
  return {x: HUB.x + Math.cos(a) * 780, y: HUB.y + Math.sin(a) * 400, tone: 'amber' as Tone};
});
/** Friend that becomes the right-hand phone in Scene 7. */
const HERO = 0;

export const PHONE_RIGHT_X = 1340;

export const Scene6Network: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const S = SCENE_STARTS[5];
  const END = SCENE_STARTS[6];
  const handoff = END - TRANSITION_FRAMES;

  const tAdd = W('যোগ');
  const tFind = W('খুঁজে');
  const tSend = W('পাঠান');
  const tReq = W('রিকোয়েস্ট');
  const tBuild = W('গড়ে');

  const cardsOut = prog(f, tSend - 10, 16);
  const reqIn = settle(f, fps, tSend, {damping: 24, stiffness: 120});
  const press = prog(f, tReq + 4, 18);
  const done = prog(f, tReq + 24, 6);
  const reqOut = prog(f, tBuild - 4, 16);
  const nodesIn = tBuild + 6;
  const morph = prog(f, handoff - 36, 36, easeInOut);
  const others = 1 - morph;


  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.15, cx: 960, cy: 540},
          {f: tBuild - 2, s: 1.15, cx: 1000, cy: 540},
          {f: tBuild + 80, s: 0.82, cx: 960, cy: 540},
          {f: handoff - 36, s: 0.82, cx: 960, cy: 540},
          {f: handoff, s: 1.0, cx: 960, cy: 540},
        ]}
      >
        <NetworkLayer>
          {RING1.map((n, i) => {
            const pp = prog(f, nodesIn + 90 + i * 14, 40);
            return (
              <ConnectionLine
                key={`a${i}`}
                x1={HUB.x}
                y1={HUB.y}
                x2={n.x}
                y2={n.y}
                progress={prog(f, nodesIn + i * 9, 26)}
                opacity={i === HERO ? 1 : others}
                pulse={i !== HERO && pp > 0 && pp < 1 ? pp : null}
                width={4.5}
              />
            );
          })}
          {RING2.map((n, i) => {
            const src = RING1[(i * 2 + 1) % 6];
            return (
              <ConnectionLine
                key={`b${i}`}
                x1={src.x}
                y1={src.y}
                x2={n.x}
                y2={n.y}
                progress={prog(f, nodesIn + 60 + i * 9, 26)}
                opacity={0.5 * others}
                width={3}
              />
            );
          })}
        </NetworkLayer>

        {/* hub profile */}
        <div style={{position: 'absolute', left: HUB.x - 85, top: HUB.y - 85, opacity: others + (1 - others) * 0}}>
          <ProfileAvatar size={170} tone="orange" />
        </div>

        {/* discovery cards */}
        {[
          {x: 190, y: 190, name: 'Rafi', tone: 'amber' as Tone, at: tAdd},
          {x: 1370, y: 180, name: 'Nila', tone: 'orange' as Tone, at: tAdd + 10},
          {x: 190, y: 800, name: 'Arif', tone: 'ink' as Tone, at: tFind},
          {x: 1370, y: 820, name: 'Sara', tone: 'amber' as Tone, at: tFind + 10},
        ].map((c) => (
          <div
            key={c.name}
            style={{
              position: 'absolute',
              left: c.x,
              top: c.y,
              opacity: prog(f, c.at, 14) * (1 - cardsOut),
              transform: `translateX(${(1 - settle(f, fps, c.at)) * (c.x < 900 ? -160 : 160)}px)`,
            }}
          >
            <ProfileCard name={c.name} tone={c.tone} w={400} />
          </div>
        ))}

        {/* friend request */}
        <div
          style={{
            position: 'absolute',
            left: 960 - 260 + 360,
            top: 540 - 150,
            opacity: Math.min(1, reqIn * 2) * (1 - reqOut),
            transform: `translateX(${(1 - reqIn) * 200}px) scale(${1 - reqOut * 0.3})`,
          }}
        >
          <FriendRequestCard name="Nila" tone="orange" press={press} done={done} w={520} />
        </div>

        {/* ring-1 friends */}
        {RING1.map((n, i) => {
          const sc = settle(f, fps, nodesIn + i * 9 + 8);
          if (i === HERO) return null;
          return (
            <div key={i} style={{position: 'absolute', left: n.x - 60, top: n.y - 60, opacity: Math.min(1, sc * 2) * others, transform: `scale(${sc})`}}>
              <ProfileAvatar size={120} tone={n.tone} />
            </div>
          );
        })}
        {RING2.map((n, i) => {
          const sc = settle(f, fps, nodesIn + 66 + i * 9);
          return (
            <div key={i} style={{position: 'absolute', left: n.x - 42, top: n.y - 42, opacity: Math.min(1, sc * 2) * 0.8 * others, transform: `scale(${sc})`}}>
              <ProfileAvatar size={84} tone={n.tone} ring={false} />
            </div>
          );
        })}

        {/* hero friend: avatar -> phone (handed over to Scene 7) */}
        {(() => {
          const n = RING1[HERO];
          const sc = settle(f, fps, nodesIn + 8);
          const appear = Math.min(1, sc * 2);
          const w = lerp(120, 300, morph);
          const h = lerp(120, 600, morph);
          const cx = lerp(n.x, PHONE_RIGHT_X, morph);
          const cy = lerp(n.y, 540, morph);
          const r = lerp(60, 52, morph);
          return (
            <div style={{position: 'absolute', left: cx - w / 2, top: cy - h / 2, width: w, height: h, opacity: f >= nodesIn ? appear : 0}}>
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  borderRadius: r,
                  background: '#222222',
                  opacity: morph,
                  boxShadow: '0 34px 70px rgba(34,34,34,0.18)',
                }}
              />
              <div style={{position: 'absolute', inset: lerp(0, 9, morph), borderRadius: lerp(60, 44, morph), background: '#fff', opacity: morph, overflow: 'hidden'}} />
              <div style={{position: 'absolute', left: (w - 120) / 2, top: (h - 120) / 2, opacity: 1 - morph}}>
                <ProfileAvatar size={120} tone={n.tone} />
              </div>
            </div>
          );
        })()}
      </Camera>
    </AbsoluteFill>
  );
};
