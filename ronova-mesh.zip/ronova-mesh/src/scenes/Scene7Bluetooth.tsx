import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Background} from '../components/Background';
import {PhoneMockup} from '../components/PhoneMockup';
import {ChatBubble} from '../components/ChatBubble';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {BluetoothConnection} from '../components/Connections';
import {GlobeIcon, SlashIcon} from '../components/Icons';
import {NetworkLayer} from '../components/Network';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, lerp, phase, prog} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';
import {C} from '../lib/theme';
import {FONT} from '../lib/fonts';
import {PHONE_RIGHT_X} from './Scene6Network';

/** Phone positions used by Scenes 7 and 8 (kept identical so the morph is continuous). */
export const NEAR = {left: 640, right: 1280};
export const FAR_POS = {left: 330, right: 1590};

const Screen: React.FC<{tone: 'orange' | 'amber'; flip?: boolean}> = ({tone, flip}) => (
  <div style={{position: 'absolute', inset: 0, padding: '58px 20px 20px', display: 'flex', flexDirection: 'column', gap: 16}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
      <ProfileAvatar size={46} tone={tone} ring={false} />
      <div style={{height: 12, width: 90, borderRadius: 99, background: C.ink, opacity: 0.8}} />
    </div>
    <div style={{alignSelf: flip ? 'flex-end' : 'flex-start'}}>
      <ChatBubble w={190} h={78} side={flip ? 'right' : 'left'} variant={flip ? 'orange' : 'white'} lines={[0.8, 0.5]} />
    </div>
    <div style={{alignSelf: flip ? 'flex-start' : 'flex-end'}}>
      <ChatBubble w={150} h={66} side={flip ? 'left' : 'right'} variant="white" lines={[0.75]} />
    </div>
  </div>
);

export const Scene7Bluetooth: React.FC = () => {
  const f = useGF();
  const S = SCENE_STARTS[6];
  const END = SCENE_STARTS[7];
  const handoff = END - TRANSITION_FRAMES;

  const tNear = W('কাছাকাছি');
  const tBt = W('ব্লুটুথ-ভিত্তিক');
  const tNet = W('ইন্টারনেট');
  const tNo = W('না', 54);
  const tIf = W('যদি');

  const approach = prog(f, S, 54, easeInOut);
  const leftX = lerp(-200, NEAR.left, approach);
  const rightX = lerp(PHONE_RIGHT_X, NEAR.right, approach);
  const draw = prog(f, tBt, 26);
  const arcs = prog(f, tBt + 14, 22);
  const t = phase(f, tBt + 20, 84);

  const nearLabel = prog(f, tNear, 18);
  const globe = prog(f, tNet, 18);
  const dim = prog(f, tNo, 20);
  const foot = prog(f, tIf, 20);

  // exit: phones separate and the link stretches into Scene 8's long-distance arc
  const sep = prog(f, handoff - 40, 40, easeInOut);
  const lx = lerp(leftX, FAR_POS.left, sep);
  const rx = lerp(rightX, FAR_POS.right, sep);
  const exitFade = 1 - sep;

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.0, cx: 960, cy: 540},
          {f: tBt - 6, s: 1.0, cx: 960, cy: 540},
          {f: tBt + 60, s: 1.28, cx: 960, cy: 540},
          {f: tNo, s: 1.28, cx: 960, cy: 540},
          {f: tIf + 20, s: 1.08, cx: 960, cy: 540},
          {f: handoff - 40, s: 1.08, cx: 960, cy: 540},
          {f: handoff, s: 1.0, cx: 960, cy: 540},
        ]}
      >
        <NetworkLayer>
          <BluetoothConnection
            x1={lx + 150}
            x2={rx - 150}
            y={540}
            draw={draw}
            arcs={arcs * exitFade}
            t={t}
          />
        </NetworkLayer>

        <div style={{position: 'absolute', left: lx - 150, top: 240, opacity: Math.min(1, approach * 3)}}>
          <PhoneMockup w={300} h={600} radius={48}>
            <Screen tone="amber" />
          </PhoneMockup>
        </div>
        <div style={{position: 'absolute', left: rx - 150, top: 240}}>
          <PhoneMockup w={300} h={600} radius={48}>
            <Screen tone="orange" flip />
          </PhoneMockup>
        </div>

        {/* labels */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 140,
            textAlign: 'center',
            fontFamily: FONT,
            fontWeight: 700,
            fontSize: 96,
            color: C.ink,
            opacity: nearLabel * exitFade,
            transform: `translateY(${(1 - nearLabel) * 24}px)`,
          }}
        >
          Nearby
        </div>

        {/* internet icon becomes visually secondary */}
        <div
          style={{
            position: 'absolute',
            left: 960 - 330,
            top: 860,
            width: 660,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 28,
            fontFamily: FONT,
            fontWeight: 700,
            fontSize: 66,
            opacity: globe * exitFade,
          }}
        >
          <div style={{position: 'relative', color: lerp(1, 0.3, dim) < 0.65 ? C.muted : C.orange, opacity: lerp(1, 0.45, dim)}}>
            <GlobeIcon size={84} sw={1.8} />
            <div style={{position: 'absolute', inset: 0}}>
              <SlashIcon size={84} sw={2.2} draw={dim} color={C.ink} />
            </div>
          </div>
          <span style={{color: C.ink}}>Internet not required*</span>
        </div>

        {/* qualification stays on screen with the claim */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 985,
            textAlign: 'center',
            fontFamily: FONT,
            fontWeight: 600,
            fontSize: 34,
            color: C.muted,
            opacity: Math.min(foot, globe) * exitFade,
          }}
        >
          *If the required Bluetooth connection and app support are available.
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
