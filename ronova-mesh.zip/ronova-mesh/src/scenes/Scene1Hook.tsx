import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {ChatBubble} from '../components/ChatBubble';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {ConnectionLine, NetworkLayer, NetworkNode} from '../components/Network';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, lerp, prog, settle} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';
import {C} from '../lib/theme';
import {FONT_BN} from '../lib/fonts';

/** Shared with Scene 2: the bubble that becomes the next scene's centrepiece. */
export const BIG_BUBBLE = {w: 420, h: 230};

const CX = 960;
const CY = 420;
// satellites on an ellipse around the hub
const SATS = [0, 1, 2, 3, 4, 5].map((k) => {
  const a = ((k * 60 - 90) * Math.PI) / 180;
  return {k, x: CX + Math.cos(a) * 520, y: CY + Math.sin(a) * 250, kind: k % 2 === 0 ? 'bubble' : 'avatar'};
});
const HERO = 1; // satellite index that becomes the big bubble

const WORDS: Array<{text: string; at: number}> = [
  {text: 'সহজ', at: W('সহজ')},
  {text: 'স্মার্ট', at: W('স্মার্ট')},
  {text: 'কাছের', at: W('কাছের')},
];

export const Scene1Hook: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const END = SCENE_STARTS[1];
  const travelEnd = END - TRANSITION_FRAMES; // bubble reaches centre before the reveal starts
  const travel = prog(f, travelEnd - 34, 34, easeInOut);
  const hubGrow = settle(f, fps, 4, {damping: 18, stiffness: 90});
  const fadeOthers = 1 - 0.85 * travel;

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: 0, s: 1.0, cx: 960, cy: 540},
          {f: travelEnd - 40, s: 1.0, cx: 960, cy: 540},
          {f: travelEnd, s: 1.08, cx: 960, cy: 540},
        ]}
      >
        <NetworkLayer>
          {SATS.map((s) => (
            <ConnectionLine
              key={s.k}
              x1={CX}
              y1={CY}
              x2={s.x}
              y2={s.y}
              progress={prog(f, 14 + s.k * 7, 22)}
              opacity={s.k === HERO ? 1 - travel : 0.45 * fadeOthers}
              width={4}
            />
          ))}
        </NetworkLayer>

        {/* hub */}
        <NetworkNode x={CX} y={CY} r={46} scale={hubGrow} opacity={fadeOthers} ringScale={prog(f, 8, 40)} />

        {SATS.map((s) => {
          const t0 = 18 + s.k * 7;
          const sc = settle(f, fps, t0);
          if (s.k === HERO) return null; // drawn separately below
          return s.kind === 'bubble' ? (
            <div key={s.k} style={{position: 'absolute', left: s.x - 95, top: s.y - 50, opacity: sc * fadeOthers, transform: `scale(${sc})`}}>
              <ChatBubble w={190} h={100} side={s.x < CX ? 'left' : 'right'} variant={s.k % 4 === 0 ? 'amber' : 'white'} lines={[0.8, 0.5]} />
            </div>
          ) : (
            <div key={s.k} style={{position: 'absolute', left: s.x - 55, top: s.y - 55, opacity: sc * fadeOthers, transform: `scale(${sc})`}}>
              <ProfileAvatar size={110} tone={s.k === 3 ? 'ink' : 'orange'} />
            </div>
          );
        })}

        {/* hero bubble: reveals with the others, then travels to the centre and grows */}
        {(() => {
          const s = SATS[HERO];
          const sc = settle(f, fps, 18 + HERO * 7);
          const w = lerp(190, BIG_BUBBLE.w, travel);
          const h = lerp(100, BIG_BUBBLE.h, travel);
          const x = lerp(s.x, 960, travel);
          const y = lerp(s.y, 540, travel);
          return (
            <div style={{position: 'absolute', left: x - w / 2, top: y - h / 2, opacity: sc, transform: `scale(${lerp(sc, 1, travel)})`}}>
              <ChatBubble w={w} h={h} side="right" variant="orange" lines={[0.8, 0.5]} />
            </div>
          );
        })()}

        {/* keyword highlights, one per spoken word */}
        <div
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 790,
            display: 'flex',
            justifyContent: 'center',
            gap: 90,
            opacity: 1 - prog(f, travelEnd - 30, 18),
          }}
        >
          {WORDS.map((w) => {
            const p = prog(f, w.at - 4, 14);
            return (
              <div
                key={w.text}
                style={{
                  position: 'relative',
                  fontFamily: FONT_BN,
                  fontWeight: 700,
                  fontSize: 120,
                  color: C.ink,
                  opacity: p,
                  transform: `translateY(${(1 - p) * 26}px)`,
                }}
              >
                {w.text}
                <div
                  style={{
                    position: 'absolute',
                    left: 0,
                    bottom: 6,
                    height: 12,
                    width: `${prog(f, w.at, 16) * 100}%`,
                    borderRadius: 6,
                    background: C.amber,
                    zIndex: -1,
                  }}
                />
              </div>
            );
          })}
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
