import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {ChatBubble} from '../components/ChatBubble';
import {PhoneMockup} from '../components/PhoneMockup';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {BrandReveal, Mark} from '../components/Brand';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, lerp, prog, settle} from '../lib/anim';
import {SCENE_STARTS} from '../config';
import {W} from '../lib/timing';
import {C} from '../lib/theme';
import {FONT} from '../lib/fonts';

export const PHONE3 = {x: 1420, y: 540};

export const Scene3Intro: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const S = SCENE_STARTS[2];
  const END = SCENE_STARTS[3];
  const tIntro = W('পরিচিত');
  const tBrand = W('রনোভাব');

  const markShift = prog(f, tIntro - 6, 30, easeInOut); // mark moves to the left brand lockup
  const phoneRise = settle(f, fps, tIntro, {damping: 24, stiffness: 90});
  const brand = prog(f, tBrand - 2, 24);
  const markScale = lerp(1.7, 0.9, markShift);
  const push = END - 44;

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.0, cx: 960, cy: 540},
          {f: push, s: 1.0, cx: 960, cy: 540},
          {f: END, s: 2.5, cx: PHONE3.x, cy: PHONE3.y},
        ]}
      >
        {/* hub mark from the previous scene's centre node */}
        <div
          style={{
            position: 'absolute',
            left: lerp(960, 330, markShift) - 95,
            top: lerp(540, 310, markShift) - 95,
            transform: `scale(${markScale * Math.min(1, prog(f, S, 18) + 0.01)})`,
          }}
        >
          <Mark size={190} draw={prog(f, S, 24)} />
        </div>

        <div style={{position: 'absolute', left: 120, top: 440, opacity: brand}}>
          <BrandReveal progress={brand} fontSize={150} />
        </div>
        <div
          style={{
            position: 'absolute',
            left: 126,
            top: 640,
            fontFamily: FONT,
            fontWeight: 600,
            fontSize: 64,
            color: C.muted,
            opacity: prog(f, tBrand + 14, 20),
          }}
        >
          Modern messaging
        </div>

        {/* phone rises into place */}
        <div
          style={{
            position: 'absolute',
            left: PHONE3.x - 190,
            top: PHONE3.y - 390 + (1 - phoneRise) * 900,
            opacity: Math.min(1, phoneRise * 3),
          }}
        >
          <PhoneMockup w={380} h={780}>
            <div style={{position: 'absolute', inset: 0, padding: '64px 26px 26px', display: 'flex', flexDirection: 'column', gap: 18}}>
              <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
                <Mark size={54} />
                <div style={{height: 16, width: 120, borderRadius: 99, background: C.ink, opacity: 0.85}} />
              </div>
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 14,
                    padding: 14,
                    borderRadius: 24,
                    background: C.white,
                    border: `2px solid ${C.border}`,
                    opacity: prog(f, tIntro + 14 + i * 7, 16),
                    transform: `translateY(${(1 - settle(f, fps, tIntro + 14 + i * 7)) * 30}px)`,
                  }}
                >
                  <ProfileAvatar size={62} tone={i === 1 ? 'amber' : 'orange'} ring={false} />
                  <div style={{flex: 1}}>
                    <div style={{height: 14, width: '60%', borderRadius: 99, background: C.ink, opacity: 0.8}} />
                    <div style={{height: 10, width: '85%', borderRadius: 99, background: C.border, marginTop: 10}} />
                  </div>
                </div>
              ))}
            </div>
          </PhoneMockup>
        </div>

        {/* interface cards settle around the phone */}
        <div style={{position: 'absolute', left: 1100, top: 780, opacity: prog(f, tIntro + 24, 16), transform: `translateY(${(1 - settle(f, fps, tIntro + 24)) * 40}px)`}}>
          <ChatBubble w={230} h={110} side="left" variant="white" lines={[0.85, 0.55]} />
        </div>
        <div style={{position: 'absolute', left: 1640, top: 230, opacity: prog(f, tIntro + 34, 16), transform: `translateY(${(1 - settle(f, fps, tIntro + 34)) * 40}px)`}}>
          <ChatBubble w={210} h={100} side="right" variant="orange" lines={[0.8, 0.5]} />
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
