import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {ChatBubble} from '../components/ChatBubble';
import {PhoneMockup} from '../components/PhoneMockup';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {CheckIcon, ChatIcon, SearchIcon, SendIcon, UserIcon} from '../components/Icons';
import {Camera, Parallax, useGF} from '../lib/scene';
import {easeInOut, lerp, prog, settle} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';
import {C} from '../lib/theme';
import {FONT} from '../lib/fonts';

const PX = 620;
const PY = 540;

const LABELS = [
  {text: 'Simple', at: W('সহজ', 25), y: 330},
  {text: 'Comfortable', at: W('স্বাচ্ছন্দ্যময়'), y: 540},
  {text: 'Smart', at: W('স্মার্ট', 28), y: 750},
];

export const Scene4Messaging: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const S = SCENE_STARTS[3];
  const END = SCENE_STARTS[4];
  const exitStart = END - TRANSITION_FRAMES - 30;
  const exit = prog(f, exitStart, 30, easeInOut);
  const tApp = W('আধুনিক', 20);

  return (
    <AbsoluteFill>
      <Background glowX={700} />
      <Camera
        keys={[
          {f: S, s: 1.5, cx: PX, cy: PY},
          {f: S + 40, s: 1.0, cx: 960, cy: 540},
          {f: exitStart, s: 1.08, cx: 900, cy: 540},
          {f: END, s: 2.2, cx: PX, cy: PY},
        ]}
      >
        <Parallax depth={-0.08}>
          <div style={{position: 'absolute', left: PX - 200, top: PY - 410}}>
            <PhoneMockup w={400} h={820}>
              <div style={{position: 'absolute', inset: 0, padding: '70px 26px 26px', display: 'flex', flexDirection: 'column', gap: 16}}>
                <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
                  <div style={{height: 22, width: 120, borderRadius: 99, background: C.ink, opacity: 0.85}} />
                  <ProfileAvatar size={54} tone="orange" ring={false} />
                </div>
                <div style={{display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px', borderRadius: 22, background: C.offWhite, color: C.muted}}>
                  <SearchIcon size={30} />
                  <div style={{height: 12, width: 140, borderRadius: 99, background: C.border}} />
                </div>
                {[0, 1, 2, 3].map((i) => {
                  const t0 = tApp + 10 + i * 9;
                  const sc = settle(f, fps, t0);
                  return (
                    <div
                      key={i}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: 14,
                        padding: 14,
                        borderRadius: 24,
                        background: i === 0 ? C.amberSoft : C.white,
                        border: `2px solid ${C.border}`,
                        opacity: prog(f, t0, 14),
                        transform: `translateX(${(1 - sc) * 70}px)`,
                      }}
                    >
                      <ProfileAvatar size={64} tone={(['orange', 'amber', 'ink', 'amber'] as const)[i]} ring={false} />
                      <div style={{flex: 1}}>
                        <div style={{height: 14, width: '55%', borderRadius: 99, background: C.ink, opacity: 0.8}} />
                        <div style={{height: 10, width: '80%', borderRadius: 99, background: C.border, marginTop: 10}} />
                      </div>
                      {i === 0 && <div style={{width: 22, height: 22, borderRadius: 11, background: C.orange}} />}
                    </div>
                  );
                })}
                <div style={{marginTop: 'auto', display: 'flex', justifyContent: 'space-around', color: C.muted}}>
                  <ChatIcon size={40} color={C.orange} />
                  <UserIcon size={40} />
                  <SendIcon size={40} />
                </div>
              </div>
            </PhoneMockup>
          </div>
        </Parallax>

        {/* floating message cards */}
        <div style={{position: 'absolute', left: 900, top: 140, opacity: prog(f, tApp + 30, 16) * (1 - exit), transform: `translateY(${(1 - settle(f, fps, tApp + 30)) * 40}px)`}}>
          <ChatBubble w={300} h={120} side="left" variant="white" lines={[0.85, 0.5]} />
        </div>
        <div style={{position: 'absolute', left: 1100, top: 905, opacity: prog(f, tApp + 44, 16) * (1 - exit), transform: `translateY(${(1 - settle(f, fps, tApp + 44)) * 40}px)`}}>
          <ChatBubble w={300} h={120} side="right" variant="orange" lines={[0.7, 0.45]} />
        </div>

        {/* keyword labels, accent responds to the spoken word */}
        {LABELS.map((l) => {
          const p = prog(f, l.at - 6, 16);
          const hot = prog(f, l.at, 10);
          return (
            <div
              key={l.text}
              style={{
                position: 'absolute',
                left: 1130,
                top: l.y - 62,
                display: 'flex',
                alignItems: 'center',
                gap: 28,
                padding: '0 44px 0 24px',
                height: 124,
                borderRadius: 62,
                background: hot > 0.5 ? C.orange : C.white,
                color: hot > 0.5 ? C.white : C.ink,
                border: `2px solid ${hot > 0.5 ? C.orange : C.border}`,
                boxShadow: '0 12px 28px rgba(34,34,34,0.08)',
                fontFamily: FONT,
                fontWeight: 700,
                fontSize: 72,
                opacity: p * (1 - exit),
                transform: `translateX(${(1 - p) * 70}px) scale(${lerp(1, 1.04, Math.sin(Math.PI * hot))})`,
              }}
            >
              <div style={{width: 76, height: 76, borderRadius: 38, background: hot > 0.5 ? 'rgba(255,255,255,0.25)' : C.amberSoft, display: 'flex', alignItems: 'center', justifyContent: 'center', color: hot > 0.5 ? C.white : C.orange}}>
                <CheckIcon size={44} sw={2.8} draw={hot} />
              </div>
              {l.text}
            </div>
          );
        })}
      </Camera>
    </AbsoluteFill>
  );
};
