import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {PhoneMockup} from '../components/PhoneMockup';
import {ChatBubble} from '../components/ChatBubble';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {OnlineConnection} from '../components/Connections';
import {ConnectionLine, NetworkLayer, NetworkNode} from '../components/Network';
import {BluetoothIcon} from '../components/Icons';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, lerp, phase, prog, settle} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';
import {C} from '../lib/theme';
import {FONT} from '../lib/fonts';
import {FAR_POS} from './Scene7Bluetooth';

const PY = 540;
const NEARBY = {x: 700, y: 840};
export const HUB_Y = 360;

const Screen: React.FC<{tone: 'orange' | 'amber'; flip?: boolean}> = ({tone, flip}) => (
  <div style={{position: 'absolute', inset: 0, padding: '58px 20px 20px', display: 'flex', flexDirection: 'column', gap: 16}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
      <ProfileAvatar size={46} tone={tone} ring={false} />
      <div style={{height: 12, width: 90, borderRadius: 99, background: C.ink, opacity: 0.8}} />
    </div>
    <div style={{alignSelf: flip ? 'flex-end' : 'flex-start'}}>
      <ChatBubble w={190} h={78} side={flip ? 'right' : 'left'} variant={flip ? 'orange' : 'white'} lines={[0.8, 0.5]} />
    </div>
    <div style={{alignSelf: flip ? 'flex-start' : 'flex-end'}}>
      <ChatBubble w={150} h={66} side={flip ? 'left' : 'right'} variant="white" lines={[0.75]} />
    </div>
  </div>
);

export const Scene8Distance: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const S = SCENE_STARTS[7];
  const END = SCENE_STARTS[8];
  const handoff = END - TRANSITION_FRAMES;

  const tFar = W('দূরে');
  const tNet = W('ইন্টারনেট', 61);
  const tOnline = W('অনলাইন');
  const tNear = W('কাছের', 65);
  const tDist = W('দূরের');

  const arc = prog(f, S + 4, 30, easeInOut);
  const badge = prog(f, tNet, 20);
  const pulse = phase(f, tNet + 10, 70);
  const nearIn = settle(f, fps, tNear);
  const nearLine = prog(f, tNear + 4, 24);
  const label1 = prog(f, tOnline, 18);
  const label2 = prog(f, tNear + 10, 18);
  const conv = prog(f, handoff - 44, 44, easeInOut);
  const keep = 1 - conv;

  const lx = FAR_POS.left;
  const rx = FAR_POS.right;
  // objects slide toward the hub node at (960, HUB_Y) while converging
  const toHub = (x: number, y: number) => ({x: lerp(x, 960, conv), y: lerp(y, HUB_Y, conv)});

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.08, cx: 960, cy: 540},
          {f: tNet + 30, s: 1.22, cx: 1180, cy: 500},
          {f: tNear - 10, s: 1.22, cx: 760, cy: 520},
          {f: tDist + 20, s: 0.92, cx: 960, cy: 560},
          {f: handoff - 44, s: 0.92, cx: 960, cy: 560},
          {f: handoff, s: 1.0, cx: 960, cy: 540},
        ]}
      >
        <NetworkLayer>
          {/* online path (top arc) */}
          <g opacity={keep}>
            <OnlineConnection x1={lx} y1={PY - 110} x2={rx} y2={PY - 110} bend={-430} progress={arc} badge={badge} pulse={badge > 0.99 ? pulse : null} />
          </g>
          {/* nearby path (short link to a close friend) */}
          <ConnectionLine x1={lx} y1={PY + 120} x2={NEARBY.x} y2={NEARBY.y} progress={nearLine * keep} width={5} />
        </NetworkLayer>

        <div style={{position: 'absolute', left: lerp(lx, 960, conv) - 150, top: lerp(PY - 300, HUB_Y - 300, conv), opacity: keep, transform: `scale(${lerp(1, 0.4, conv)})`}}>
          <PhoneMockup w={300} h={600} radius={48}>
            <Screen tone="amber" />
          </PhoneMockup>
        </div>
        <div style={{position: 'absolute', left: lerp(rx, 960, conv) - 150, top: lerp(PY - 300, HUB_Y - 300, conv), opacity: keep, transform: `scale(${lerp(1, 0.4, conv)})`}}>
          <PhoneMockup w={300} h={600} radius={48}>
            <Screen tone="orange" flip />
          </PhoneMockup>
        </div>

        {/* nearby friend + Bluetooth badge */}
        {(() => {
          const p = toHub(NEARBY.x, NEARBY.y);
          return (
            <div style={{position: 'absolute', left: p.x - 60, top: p.y - 60, opacity: Math.min(1, nearIn * 2) * keep, transform: `scale(${nearIn * lerp(1, 0.4, conv)})`}}>
              <ProfileAvatar size={120} tone="ink" />
            </div>
          );
        })()}
        <div
          style={{
            position: 'absolute',
            left: (lx + NEARBY.x) / 2 - 38,
            top: (PY + 120 + NEARBY.y) / 2 - 38,
            width: 76,
            height: 76,
            borderRadius: 38,
            background: C.orange,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: C.white,
            opacity: nearLine * keep,
          }}
        >
          <BluetoothIcon size={42} sw={2.4} draw={nearLine} />
        </div>

        {/* path labels */}
        <div style={{position: 'absolute', left: 960 - 200, top: 130, width: 400, textAlign: 'center', fontFamily: FONT, fontWeight: 700, fontSize: 72, color: C.ink, opacity: label1 * keep}}>
          Online
        </div>
        <div style={{position: 'absolute', left: NEARBY.x + 90, top: NEARBY.y - 44, fontFamily: FONT, fontWeight: 700, fontSize: 72, color: C.ink, opacity: label2 * keep}}>
          Nearby
        </div>

        {/* converged hub node, handed over to Scene 9 */}
        <NetworkNode x={960} y={HUB_Y} r={46} scale={conv} opacity={conv} />
      </Camera>
    </AbsoluteFill>
  );
};
