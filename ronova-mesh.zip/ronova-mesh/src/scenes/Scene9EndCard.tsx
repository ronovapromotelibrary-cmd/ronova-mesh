import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Background} from '../components/Background';
import {EndCard} from '../components/Brand';
import {ConnectionLine, NetworkLayer, NetworkNode} from '../components/Network';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, prog} from '../lib/anim';
import {SCENE_STARTS} from '../config';
import {W} from '../lib/timing';
import {HUB_Y} from './Scene8Distance';

export const Scene9EndCard: React.FC = () => {
  const f = useGF();
  const S = SCENE_STARTS[8];

  const tProfile = W('প্রোফাইল', 72);
  const tFriend = W('বন্ধুত্ব', 73);
  const tNetwork = W('নেটওয়ার্ক', 74);
  const tTogether = W('একটি', 75);
  const tBrand = W('রনোভাব', 78);
  const tTag = W('স্টে');

  const icons: [number, number, number] = [prog(f, tProfile - 4, 18), prog(f, tFriend - 4, 18), prog(f, tNetwork - 4, 18)];
  const converge = prog(f, tTogether, 30, easeInOut);
  const mark = prog(f, tTogether + 14, 34);
  const brand = prog(f, tBrand - 2, 24);
  const tagline = prog(f, tTag - 2, 20);
  const nodeFade = 1 - prog(f, tTogether + 10, 16);

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.0, cx: 960, cy: 540},
          {f: tNetwork + 20, s: 1.0, cx: 960, cy: 540},
          {f: tBrand + 30, s: 1.0, cx: 960, cy: 540},
        ]}
      >
        <NetworkLayer>
          {[-400, 0, 400].map((dx, i) =>
            dx === 0 ? null : (
              <ConnectionLine key={i} x1={960} y1={HUB_Y} x2={960 + dx} y2={HUB_Y} progress={icons[i] * (1 - converge)} opacity={nodeFade} width={4.5} />
            ),
          )}
        </NetworkLayer>
        <NetworkNode x={960} y={HUB_Y} r={46} opacity={nodeFade} ringScale={prog(f, S, 40)} />
        <EndCard icons={icons} converge={converge} mark={mark} brand={brand} tagline={tagline} />
      </Camera>
    </AbsoluteFill>
  );
};
