import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {ChatBubble} from '../components/ChatBubble';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {MomentCard} from '../components/Cards';
import {ConnectionLine, NetworkLayer, NetworkNode} from '../components/Network';
import {Camera, useGF} from '../lib/scene';
import {arcPoint, easeInOut, lerp, prog, settle} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';
import {BIG_BUBBLE} from './Scene1Hook';

const A = {x: 470, y: 600};
const B = {x: 1450, y: 600};
const FAR: Array<{x: number; y: number}> = [
  {x: 150, y: 330},
  {x: 800, y: 210},
  {x: 1700, y: 300},
  {x: 1160, y: 900},
  {x: 260, y: 880},
];

export const Scene2Message: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const S = SCENE_STARTS[1];
  const END = SCENE_STARTS[2];
  const exitStart = END - TRANSITION_FRAMES - 26;

  const tSend = W('পাঠানো');
  const tConnect = W('সংযুক্ত', 7);
  const tMoment = W('মুহূর্ত');
  const tShare = W('ভাগ');
  const tFar = W('দূরত্বকে');

  // 1) big bubble shrinks and moves to profile A
  const shrink = prog(f, S, 26, easeInOut);
  // 2) bubble travels A -> B
  const travel = prog(f, tSend, 40, easeInOut);
  const pos = arcPoint(A.x, A.y - 120, B.x, B.y - 120, -150, travel);
  const bx = f < tSend ? lerp(960, A.x, shrink) : pos.x;
  const by = f < tSend ? lerp(540, A.y - 120, shrink) : pos.y;
  const bw = lerp(BIG_BUBBLE.w, 170, shrink);
  const bh = lerp(BIG_BUBBLE.h, 92, shrink);
  const landed = prog(f, tSend + 40, 10);
  const bubbleOp = 1 - landed;

  const line = prog(f, tConnect - 8, 34);
  const exit = prog(f, exitStart, 26, easeInOut);

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.12, cx: 960, cy: 540},
          {f: tSend + 40, s: 1.0, cx: 1000, cy: 560},
          {f: tFar + 40, s: 0.88, cx: 960, cy: 540},
          {f: END, s: 0.82, cx: 960, cy: 540},
        ]}
      >
        <NetworkLayer>
          <ConnectionLine x1={A.x} y1={A.y} x2={B.x} y2={B.y} bend={-90} progress={line * (1 - exit)} />
          {FAR.map((n, i) => (
            <React.Fragment key={i}>
              <ConnectionLine
                x1={i % 2 === 0 ? A.x : B.x}
                y1={A.y}
                x2={n.x}
                y2={n.y}
                progress={prog(f, tFar + i * 8, 28) * (1 - exit)}
                opacity={0.55}
                width={3.5}
              />
            </React.Fragment>
          ))}
        </NetworkLayer>

        {FAR.map((n, i) => {
          const sc = settle(f, fps, tFar + 10 + i * 8);
          return <NetworkNode key={i} x={n.x} y={n.y} r={26} tone={i % 2 ? 'amber' : 'orange'} scale={sc} opacity={1 - exit} />;
        })}

        {/* profiles */}
        {[
          {p: A, tone: 'amber' as const, at: S + 6},
          {p: B, tone: 'orange' as const, at: S + 12},
        ].map(({p, tone, at}) => (
          <div
            key={tone}
            style={{
              position: 'absolute',
              left: lerp(p.x, 960, exit) - 90,
              top: lerp(p.y, 540, exit) - 90,
              opacity: 1 - exit,
              transform: `scale(${settle(f, fps, at) * (1 - exit * 0.5)})`,
            }}
          >
            <ProfileAvatar size={180} tone={tone} />
          </div>
        ))}

        {/* shared-moment cards */}
        <div style={{position: 'absolute', left: 690, top: 150, opacity: prog(f, tMoment, 18) * (1 - exit), transform: `translateY(${(1 - prog(f, tMoment, 26)) * 60}px)`}}>
          <MomentCard hue="a" />
        </div>
        <div style={{position: 'absolute', left: 930, top: 260, opacity: prog(f, tShare, 18) * (1 - exit), transform: `translateY(${(1 - prog(f, tShare, 26)) * 60}px)`}}>
          <MomentCard hue="b" w={260} h={190} />
        </div>

        {/* travelling message bubble */}
        <div style={{position: 'absolute', left: bx - bw / 2, top: by - bh / 2, opacity: bubbleOp}}>
          <ChatBubble w={bw} h={bh} side={f < tSend ? 'right' : 'left'} variant="orange" lines={[0.8, 0.5]} />
        </div>

        {/* exit: nodes converge into one centre node, handing over to Scene 3's mark */}
        <NetworkNode x={960} y={540} r={46} scale={exit} opacity={exit} />
      </Camera>
    </AbsoluteFill>
  );
};
