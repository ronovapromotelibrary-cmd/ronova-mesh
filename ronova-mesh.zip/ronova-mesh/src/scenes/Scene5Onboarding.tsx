import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {Background} from '../components/Background';
import {ProfileAvatar} from '../components/ProfileAvatar';
import {Mark} from '../components/Brand';
import {CheckIcon, KeyIcon} from '../components/Icons';
import {Camera, useGF} from '../lib/scene';
import {easeInOut, lerp, prog, settle} from '../lib/anim';
import {SCENE_STARTS, TRANSITION_FRAMES} from '../config';
import {W} from '../lib/timing';
import {C, SHADOW} from '../lib/theme';
import {FONT} from '../lib/fonts';

export const Scene5Onboarding: React.FC = () => {
  const f = useGF();
  const {fps} = useVideoConfig();
  const S = SCENE_STARTS[4];
  const END = SCENE_STARTS[5];
  const tSign = W('সাইন');
  const tCreate = W('তৈরি');
  const tProfile = W('প্রোফাইল', 35);
  const handoff = END - TRANSITION_FRAMES; // avatar reaches the centre of Scene 6 here

  const cardIn = settle(f, fps, S + 4, {damping: 26, stiffness: 110});
  const highlight = prog(f, tSign - 4, 14);
  const press = prog(f, tSign + 6, 16);
  const swap = prog(f, tCreate - 10, 22, easeInOut); // sign-in -> profile
  const outline = prog(f, tCreate, 40);
  const fill = prog(f, tCreate + 34, 24);
  const nameTyped = prog(f, tProfile - 6, 40);
  const toCentre = prog(f, handoff - 28, 28, easeInOut);
  const cardOp = 1 - toCentre;

  return (
    <AbsoluteFill>
      <Background />
      <Camera
        keys={[
          {f: S, s: 1.0, cx: 960, cy: 540},
          {f: handoff, s: 1.08, cx: 960, cy: 540},
        ]}
      >
        {/* card */}
        <div
          style={{
            position: 'absolute',
            left: 960 - 380,
            top: 540 - 330 + (1 - cardIn) * 80,
            width: 760,
            height: 660,
            boxSizing: 'border-box',
            borderRadius: 48,
            background: C.white,
            border: `2px solid ${C.border}`,
            boxShadow: SHADOW,
            opacity: Math.min(1, cardIn * 2) * cardOp,
            overflow: 'hidden',
            fontFamily: FONT,
          }}
        >
          {/* sign-in face */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              padding: 56,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 36,
              opacity: 1 - swap,
              transform: `translateX(${-swap * 120}px)`,
            }}
          >
            <Mark size={130} />
            <div style={{fontSize: 72, fontWeight: 700, color: C.ink}}>Sign in</div>
            <div
              style={{
                width: '100%',
                height: 118,
                borderRadius: 59,
                border: `3px solid ${lerp(0, 1, highlight) > 0.5 ? C.orange : C.border}`,
                background: lerp(0, 1, press) > 0.4 ? C.amberSoft : C.white,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 22,
                fontSize: 46,
                fontWeight: 600,
                color: C.ink,
                boxShadow: highlight > 0.3 ? `0 0 0 ${highlight * 14}px rgba(242,140,40,${0.18 * (1 - press)})` : 'none',
                transform: `scale(${1 - 0.04 * Math.sin(Math.PI * press)})`,
              }}
            >
              <KeyIcon size={52} color={C.orange} sw={2.2} />
              Continue with account
            </div>
          </div>

          {/* profile face */}
          <div
            style={{
              position: 'absolute',
              inset: 0,
              padding: 56,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 30,
              opacity: swap,
              transform: `translateX(${(1 - swap) * 120}px)`,
            }}
          >
            <div style={{fontSize: 60, fontWeight: 700, color: C.ink}}>Your profile</div>
            <ProfileAvatar size={190} tone="orange" outline={outline} fill={fill} />
            <div
              style={{
                width: '100%',
                height: 96,
                borderRadius: 28,
                border: `3px solid ${C.border}`,
                display: 'flex',
                alignItems: 'center',
                padding: '0 32px',
                fontSize: 48,
                fontWeight: 600,
                color: C.ink,
              }}
            >
              {'Maya Rahman'.slice(0, Math.round(nameTyped * 11))}
              <span style={{width: 4, height: 52, background: C.orange, marginLeft: 4, opacity: nameTyped < 1 ? 1 : 0}} />
            </div>
            <div style={{display: 'flex', alignItems: 'center', gap: 14, color: C.orange, fontSize: 40, fontWeight: 600, opacity: fill}}>
              <CheckIcon size={44} sw={2.8} /> Profile ready
            </div>
          </div>
        </div>

        {/* avatar leaves the card and settles at the centre as Scene 6's hub */}
        {toCentre > 0 && (
          <div
            style={{
              position: 'absolute',
              left: 960 - lerp(190, 170, toCentre) / 2,
              top: lerp(465, 540, toCentre) - lerp(190, 170, toCentre) / 2,
            }}
          >
            <ProfileAvatar size={lerp(190, 170, toCentre)} tone="orange" />
          </div>
        )}
      </Camera>
    </AbsoluteFill>
  );
};
