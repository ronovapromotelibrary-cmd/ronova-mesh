import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Audio} from '@remotion/media';
import {staticFile} from 'remotion';
import {AUDIO_FILE, DURATION_FRAMES, SCENE_STARTS, TRANSITION_FRAMES} from './config';
import {Scene, Stage} from './lib/scene';
import './lib/fonts';
import {Scene1Hook} from './scenes/Scene1Hook';
import {Scene2Message} from './scenes/Scene2Message';
import {Scene3Intro} from './scenes/Scene3Intro';
import {Scene4Messaging} from './scenes/Scene4Messaging';
import {Scene5Onboarding} from './scenes/Scene5Onboarding';
import {Scene6Network} from './scenes/Scene6Network';
import {Scene7Bluetooth} from './scenes/Scene7Bluetooth';
import {Scene8Distance} from './scenes/Scene8Distance';
import {Scene9EndCard} from './scenes/Scene9EndCard';

const SCENES: Array<{name: string; C: React.FC}> = [
  {name: '1 Opening Hook', C: Scene1Hook},
  {name: '2 More Than a Message', C: Scene2Message},
  {name: '3 Introducing Ronova Mesh', C: Scene3Intro},
  {name: '4 Modern Messaging', C: Scene4Messaging},
  {name: '5 Simple Onboarding', C: Scene5Onboarding},
  {name: '6 Friends and Network', C: Scene6Network},
  {name: '7 Nearby Bluetooth', C: Scene7Bluetooth},
  {name: '8 Connect Across Distance', C: Scene8Distance},
  {name: '9 Brand End Card', C: Scene9EndCard},
];

/**
 * Orchestrator. Scene i (i>0) is mounted TRANSITION_FRAMES before its first spoken word so its
 * circular reveal plays inside the pause; the previous scene stays mounted underneath until the
 * reveal completes (so scene i spans [start_i - T, start_{i+1}]).
 */
export const RonovaMeshPromo: React.FC = () => (
  <AbsoluteFill>
    <Stage>
      {SCENES.map(({name, C}, i) => {
        const start = SCENE_STARTS[i];
        const next = i < SCENES.length - 1 ? SCENE_STARTS[i + 1] : DURATION_FRAMES;
        const from = i === 0 ? 0 : start - TRANSITION_FRAMES;
        return (
          <Scene key={name} name={name} from={from} duration={next - from} transitionIn={i === 0 ? 0 : TRANSITION_FRAMES}>
            <C />
          </Scene>
        );
      })}
    </Stage>
    {/* Original, unmodified voice-over starting at frame 0 */}
    <Audio src={staticFile(AUDIO_FILE)} />
  </AbsoluteFill>
);
