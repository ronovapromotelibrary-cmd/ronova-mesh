import React from 'react';
import {C, SHADOW_SM} from '../lib/theme';
import {FONT} from '../lib/fonts';

/**
 * Chat bubble. Without `text`, renders neutral skeleton bars (`lines` = relative widths).
 */
export const ChatBubble: React.FC<{
  w: number;
  h: number;
  side?: 'left' | 'right';
  variant?: 'orange' | 'white' | 'amber';
  text?: string;
  fontSize?: number;
  lines?: number[];
  style?: React.CSSProperties;
}> = ({w, h, side = 'left', variant = 'white', text, fontSize = 34, lines = [0.8, 0.5], style}) => {
  const bg = variant === 'orange' ? C.orange : variant === 'amber' ? C.amber : C.white;
  const fg = variant === 'orange' ? C.white : C.ink;
  const bar = variant === 'orange' ? 'rgba(255,255,255,0.75)' : variant === 'amber' ? 'rgba(34,34,34,0.25)' : C.border;
  const r = Math.min(h / 2, 34);
  return (
    <div
      style={{
        width: w,
        height: h,
        boxSizing: 'border-box',
        background: bg,
        color: fg,
        borderRadius: r,
        borderBottomLeftRadius: side === 'left' ? 8 : r,
        borderBottomRightRadius: side === 'right' ? 8 : r,
        border: variant === 'white' ? `2px solid ${C.border}` : 'none',
        boxShadow: SHADOW_SM,
        padding: `${Math.max(12, h * 0.2)}px ${Math.max(16, h * 0.22)}px`,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        gap: Math.max(8, h * 0.1),
        fontFamily: FONT,
        fontWeight: 600,
        fontSize,
        ...style,
      }}
    >
      {text ? (
        <span>{text}</span>
      ) : (
        lines.map((l, i) => (
          <div key={i} style={{height: Math.max(8, h * 0.09), width: `${l * 100}%`, borderRadius: 99, background: bar}} />
        ))
      )}
    </div>
  );
};
