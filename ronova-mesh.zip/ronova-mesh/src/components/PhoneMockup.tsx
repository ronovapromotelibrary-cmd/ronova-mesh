import React from 'react';
import {C} from '../lib/theme';

/** Premium smartphone frame built from CSS geometry. Children render inside the screen. */
export const PhoneMockup: React.FC<{
  w?: number;
  h?: number;
  radius?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}> = ({w = 360, h = 740, radius = 56, children, style}) => {
  const bezel = Math.max(8, w * 0.03);
  return (
    <div
      style={{
        position: 'relative',
        width: w,
        height: h,
        boxSizing: 'border-box',
        borderRadius: radius,
        background: '#222222',
        padding: bezel,
        boxShadow: '0 34px 70px rgba(34,34,34,0.18), 0 4px 10px rgba(34,34,34,0.10)',
        ...style,
      }}
    >
      <div
        style={{
          position: 'relative',
          width: '100%',
          height: '100%',
          borderRadius: Math.max(8, radius - bezel),
          background: C.white,
          overflow: 'hidden',
        }}
      >
        {children}
      </div>
      <div
        style={{
          position: 'absolute',
          top: bezel + 12,
          left: '50%',
          marginLeft: -w * 0.12,
          width: w * 0.24,
          height: Math.max(12, w * 0.05),
          borderRadius: 99,
          background: '#222222',
        }}
      />
    </div>
  );
};
