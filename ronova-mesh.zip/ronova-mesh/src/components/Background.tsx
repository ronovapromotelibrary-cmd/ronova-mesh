import React from 'react';
import {AbsoluteFill} from 'remotion';
import {C} from '../lib/theme';
import {Parallax, useGF} from '../lib/scene';

/** Warm off-white backdrop with a soft amber glow and a faint dot grid (parallax depth layer). */
export const Background: React.FC<{glowX?: number; glowY?: number}> = ({glowX = 960, glowY = 480}) => {
  const f = useGF();
  const drift = Math.sin(f / 160) * 24;
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{backgroundColor: C.offWhite}} />
      <Parallax depth={0.7}>
        <AbsoluteFill
          style={{
            inset: -700,
            width: 'auto',
            height: 'auto',
            backgroundImage: `radial-gradient(circle at ${glowX + 700 + drift}px ${glowY + 700}px, rgba(255,196,107,0.30) 0px, rgba(255,196,107,0.10) 520px, rgba(250,248,244,0) 980px), radial-gradient(${C.border} 2px, transparent 2.5px)`,
            backgroundSize: 'auto, 56px 56px',
          }}
        />
      </Parallax>
    </AbsoluteFill>
  );
};
