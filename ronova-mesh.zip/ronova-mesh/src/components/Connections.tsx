import React from 'react';
import {C} from '../lib/theme';
import {arcPath} from '../lib/anim';
import {BluetoothIcon, GlobeIcon} from './Icons';
import {ConnectionLine} from './Network';

/**
 * Illustrative Bluetooth link between two points: a draw-on Bluetooth badge in the middle and
 * orange signal arcs that radiate outward from the badge. Purely conceptual — it does not claim
 * that discovery, range or message delivery work. Use inside <NetworkLayer>.
 * draw: badge draw-on 0..1; arcs: 0..1 arc visibility; t: looping phase 0..1.
 */
export const BluetoothConnection: React.FC<{
  x1: number;
  x2: number;
  y: number;
  draw: number;
  arcs: number;
  t: number;
}> = ({x1, x2, y, draw, arcs, t}) => {
  const mid = (x1 + x2) / 2;
  const half = (x2 - x1) / 2;
  const rings = [0, 1, 2].map((k) => {
    const u = (t + k / 3) % 1;
    const r = 56 + u * (half - 56);
    const op = Math.sin(Math.PI * u) * 0.85 * arcs;
    const a = 0.62; // half opening angle in radians
    const sx = Math.cos(a) * r;
    const sy = Math.sin(a) * r;
    return {r, op, sx, sy, k};
  });
  return (
    <g>
      <ConnectionLine x1={x1} y1={y} x2={x2} y2={y} progress={arcs} width={4} opacity={0.35} />
      {rings.map(({r, op, sx, sy, k}) => (
        <React.Fragment key={k}>
          <path
            d={`M ${mid + sx} ${y - sy} A ${r} ${r} 0 0 0 ${mid + sx} ${y + sy}`}
            fill="none"
            stroke={C.orange}
            strokeWidth={6}
            strokeLinecap="round"
            opacity={op}
          />
          <path
            d={`M ${mid - sx} ${y - sy} A ${r} ${r} 0 0 1 ${mid - sx} ${y + sy}`}
            fill="none"
            stroke={C.orange}
            strokeWidth={6}
            strokeLinecap="round"
            opacity={op}
          />
        </React.Fragment>
      ))}
      <circle cx={mid} cy={y} r={52} fill={C.orange} opacity={Math.min(1, draw * 3)} />
      <foreignObject x={mid - 30} y={y - 30} width={60} height={60}>
        <BluetoothIcon size={60} color={C.white} sw={2.2} draw={draw} />
      </foreignObject>
    </g>
  );
};

/**
 * Long-distance online link: arced orange line with a globe badge at its apex and a travelling
 * pulse. Use inside <NetworkLayer>.
 */
export const OnlineConnection: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  bend: number;
  progress: number;
  badge: number;
  pulse: number | null;
}> = ({x1, y1, x2, y2, bend, progress, badge, pulse}) => {
  // apex of the quadratic bezier is at t = 0.5
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const len = Math.hypot(x2 - x1, y2 - y1) || 1;
  const ax = mx + (-(y2 - y1) / len) * (bend / 2);
  const ay = my + ((x2 - x1) / len) * (bend / 2);
  return (
    <g>
      <ConnectionLine x1={x1} y1={y1} x2={x2} y2={y2} bend={bend} progress={progress} pulse={pulse} />
      <g opacity={badge} transform={`translate(${ax} ${ay}) scale(${0.6 + 0.4 * badge})`}>
        <circle r={52} fill={C.white} stroke={C.border} strokeWidth={2} />
        <foreignObject x={-30} y={-30} width={60} height={60}>
          <GlobeIcon size={60} color={C.orange} sw={1.8} />
        </foreignObject>
      </g>
    </g>
  );
};

export {arcPath};
