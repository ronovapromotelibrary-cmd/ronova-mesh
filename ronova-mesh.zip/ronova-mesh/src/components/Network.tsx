import React from 'react';
import {WIDTH, HEIGHT} from '../config';
import {C} from '../lib/theme';
import {arcPath, arcPoint} from '../lib/anim';

/** Full-stage SVG layer for connection lines and pulses. */
export const NetworkLayer: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', ...style}}>
    {children}
  </svg>
);

/**
 * Thin orange connection line (straight or arced). Use inside <NetworkLayer>.
 * progress: 0..1 draw-on; pulse: optional 0..1 position of a glowing dot travelling along the line.
 */
export const ConnectionLine: React.FC<{
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  bend?: number;
  progress?: number;
  width?: number;
  color?: string;
  opacity?: number;
  pulse?: number | null;
}> = ({x1, y1, x2, y2, bend = 0, progress = 1, width = 5, color = C.orange, opacity = 1, pulse = null}) => {
  const p = pulse === null ? null : arcPoint(x1, y1, x2, y2, bend, pulse);
  return (
    <g opacity={opacity}>
      <path
        d={arcPath(x1, y1, x2, y2, bend)}
        fill="none"
        stroke={color}
        strokeWidth={width}
        strokeLinecap="round"
        pathLength={1}
        strokeDasharray={1}
        strokeDashoffset={1 - progress}
      />
      {p && progress > 0.98 && (
        <>
          <circle cx={p.x} cy={p.y} r={width * 3.2} fill={color} opacity={0.18} />
          <circle cx={p.x} cy={p.y} r={width * 1.5} fill={color} />
        </>
      )}
    </g>
  );
};

/** Absolutely-positioned circular node with soft ring; children (e.g. an avatar) render inside. */
export const NetworkNode: React.FC<{
  x: number;
  y: number;
  r?: number;
  tone?: 'orange' | 'amber' | 'ink' | 'white';
  scale?: number;
  opacity?: number;
  ringScale?: number;
  children?: React.ReactNode;
}> = ({x, y, r = 40, tone = 'orange', scale = 1, opacity = 1, ringScale = 0, children}) => {
  const bg = tone === 'orange' ? C.orange : tone === 'amber' ? C.amber : tone === 'ink' ? C.ink : C.white;
  return (
    <div style={{position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2, opacity, transform: `scale(${scale})`}}>
      {ringScale > 0 && (
        <div
          style={{
            position: 'absolute',
            inset: -r * 0.6 * ringScale,
            borderRadius: '50%',
            border: `3px solid ${C.orange}`,
            opacity: 0.35 * (1 - ringScale * 0.6),
          }}
        />
      )}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: '50%',
          background: children ? 'transparent' : bg,
          boxShadow: children ? 'none' : '0 8px 22px rgba(242,140,40,0.35)',
          border: tone === 'white' ? `2px solid ${C.border}` : 'none',
        }}
      >
        {children}
      </div>
    </div>
  );
};
