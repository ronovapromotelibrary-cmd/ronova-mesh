import React from 'react';
import {C, SHADOW} from '../lib/theme';
import {FONT} from '../lib/fonts';
import {ProfileAvatar, Tone} from './ProfileAvatar';
import {CheckIcon, UserPlusIcon} from './Icons';

const card = (w: number): React.CSSProperties => ({
  width: w,
  boxSizing: 'border-box',
  background: C.white,
  border: `2px solid ${C.border}`,
  borderRadius: 32,
  boxShadow: SHADOW,
  fontFamily: FONT,
});

/** Profile card: avatar, name, skeleton subtitle. */
export const ProfileCard: React.FC<{
  w?: number;
  name: string;
  tone?: Tone;
  style?: React.CSSProperties;
}> = ({w = 380, name, tone = 'amber', style}) => (
  <div style={{...card(w), padding: 28, display: 'flex', alignItems: 'center', gap: 24, ...style}}>
    <ProfileAvatar size={96} tone={tone} />
    <div style={{flex: 1}}>
      <div style={{fontSize: 40, fontWeight: 700, color: C.ink, lineHeight: 1.1}}>{name}</div>
      <div style={{height: 12, width: '70%', borderRadius: 99, background: C.border, marginTop: 16}} />
    </div>
  </div>
);

/**
 * Friend-request card. press: 0..1 button press feedback; done: 0..1 "Sent" state.
 * Illustrative UI only.
 */
export const FriendRequestCard: React.FC<{
  w?: number;
  name: string;
  tone?: Tone;
  press?: number;
  done?: number;
  style?: React.CSSProperties;
}> = ({w = 520, name, tone = 'amber', press = 0, done = 0, style}) => {
  const squash = 1 - 0.06 * Math.sin(Math.PI * Math.min(1, press));
  const ripple = press > 0 && press < 1 ? press : 0;
  return (
    <div style={{...card(w), padding: 34, ...style}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 28}}>
        <ProfileAvatar size={120} tone={tone} />
        <div>
          <div style={{fontSize: 52, fontWeight: 700, color: C.ink, lineHeight: 1.1}}>{name}</div>
          <div style={{height: 14, width: 190, borderRadius: 99, background: C.border, marginTop: 18}} />
        </div>
      </div>
      <div
        style={{
          position: 'relative',
          marginTop: 34,
          height: 92,
          borderRadius: 46,
          background: done > 0.5 ? C.amberSoft : C.orange,
          color: done > 0.5 ? C.orange : C.white,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 14,
          fontSize: 44,
          fontWeight: 700,
          overflow: 'hidden',
          transform: `scale(${squash})`,
        }}
      >
        {ripple > 0 && (
          <div
            style={{
              position: 'absolute',
              left: '50%',
              top: '50%',
              width: ripple * w * 1.2,
              height: ripple * w * 1.2,
              marginLeft: -(ripple * w * 0.6),
              marginTop: -(ripple * w * 0.6),
              borderRadius: '50%',
              background: 'rgba(255,255,255,0.35)',
              opacity: 1 - ripple,
            }}
          />
        )}
        {done > 0.5 ? <CheckIcon size={48} sw={2.6} /> : <UserPlusIcon size={48} sw={2.4} />}
        <span>{done > 0.5 ? 'Sent' : 'Add Friend'}</span>
      </div>
    </div>
  );
};

/** Abstract "shared moment" card (sun + hills in amber/orange). */
export const MomentCard: React.FC<{w?: number; h?: number; hue?: 'a' | 'b'; style?: React.CSSProperties}> = ({
  w = 300,
  h = 220,
  hue = 'a',
  style,
}) => (
  <div style={{...card(w), height: h, padding: 14, ...style}}>
    <svg width="100%" height="100%" viewBox="0 0 280 192" style={{borderRadius: 20, display: 'block'}}>
      <rect width="280" height="192" fill={hue === 'a' ? '#FFF1DB' : '#FDE8D0'} />
      <circle cx={hue === 'a' ? 200 : 82} cy="62" r="26" fill={C.orange} />
      <path d="M0 192 L0 128 L70 84 L130 128 L190 92 L280 150 L280 192 Z" fill={C.amber} />
      <path d="M0 192 L0 154 L84 120 L160 160 L230 128 L280 156 L280 192 Z" fill="#F7A94B" />
    </svg>
  </div>
);
