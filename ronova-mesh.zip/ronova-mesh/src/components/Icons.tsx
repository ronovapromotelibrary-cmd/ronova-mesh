import React from 'react';

type P = {size?: number; color?: string; sw?: number; style?: React.CSSProperties; draw?: number};

const Base: React.FC<P & {children: React.ReactNode}> = ({size = 48, color = 'currentColor', sw = 2, style, children}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={sw}
    strokeLinecap="round"
    strokeLinejoin="round"
    style={style}
  >
    {children}
  </svg>
);

/** dash helper so any stroke can be "drawn on" with progress 0..1 (needs pathLength=1). */
const dash = (p = 1): React.CSSProperties => ({strokeDasharray: 1, strokeDashoffset: 1 - p});

export const ChatIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <path
      pathLength={1}
      style={dash(p.draw)}
      d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"
    />
  </Base>
);

export const UserIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <path pathLength={1} style={dash(p.draw)} d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
    <circle pathLength={1} style={dash(p.draw)} cx="12" cy="7" r="4" />
  </Base>
);

export const UsersIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <path pathLength={1} style={dash(p.draw)} d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
    <circle pathLength={1} style={dash(p.draw)} cx="9" cy="7" r="4" />
    <path pathLength={1} style={dash(p.draw)} d="M23 21v-2a4 4 0 0 0-3-3.87" />
    <path pathLength={1} style={dash(p.draw)} d="M16 3.13a4 4 0 0 1 0 7.75" />
  </Base>
);

export const UserPlusIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
    <circle cx="8.5" cy="7" r="4" />
    <line x1="20" y1="8" x2="20" y2="14" />
    <line x1="23" y1="11" x2="17" y2="11" />
  </Base>
);

export const NetworkIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <circle cx="12" cy="5" r="2.6" />
    <circle cx="5" cy="18" r="2.6" />
    <circle cx="19" cy="18" r="2.6" />
    <line x1="10.9" y1="7.3" x2="6.2" y2="15.7" />
    <line x1="13.1" y1="7.3" x2="17.8" y2="15.7" />
    <line x1="7.6" y1="18" x2="16.4" y2="18" />
  </Base>
);

export const BluetoothIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <polyline pathLength={1} style={dash(p.draw)} points="6.5 6.5 17.5 17.5 12 23 12 1 17.5 6.5 6.5 17.5" />
  </Base>
);

export const GlobeIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <circle pathLength={1} style={dash(p.draw)} cx="12" cy="12" r="10" />
    <line pathLength={1} style={dash(p.draw)} x1="2" y1="12" x2="22" y2="12" />
    <path
      pathLength={1}
      style={dash(p.draw)}
      d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"
    />
  </Base>
);

export const CheckIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <polyline pathLength={1} style={dash(p.draw)} points="20 6 9 17 4 12" />
  </Base>
);

export const SearchIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <circle cx="11" cy="11" r="8" />
    <line x1="21" y1="21" x2="16.65" y2="16.65" />
  </Base>
);

export const SendIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <line x1="22" y1="2" x2="11" y2="13" />
    <polygon points="22 2 15 22 11 13 2 9 22 2" />
  </Base>
);

export const KeyIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <circle cx="8" cy="15" r="4" />
    <line x1="10.85" y1="12.15" x2="21" y2="2" />
    <line x1="18" y1="5" x2="21" y2="8" />
  </Base>
);

export const SlashIcon: React.FC<P> = (p) => (
  <Base {...p}>
    <line pathLength={1} style={dash(p.draw)} x1="3" y1="3" x2="21" y2="21" />
  </Base>
);
