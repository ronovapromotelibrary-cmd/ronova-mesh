import React from 'react';
import {C} from '../lib/theme';
import {FONT} from '../lib/fonts';
import {ProfileAvatar} from './ProfileAvatar';
import {NetworkIcon, UsersIcon, UserIcon} from './Icons';

/** Original geometric network mark (no supplied logo asset): hub node + three satellites. */
export const Mark: React.FC<{size?: number; draw?: number; style?: React.CSSProperties}> = ({size = 120, draw = 1, style}) => {
  const pts = [-90, 30, 150].map((deg) => {
    const a = (deg * Math.PI) / 180;
    return {x: 60 + Math.cos(a) * 40, y: 60 + Math.sin(a) * 40};
  });
  return (
    <svg width={size} height={size} viewBox="0 0 120 120" style={style}>
      {pts.map((p, i) => (
        <line
          key={i}
          x1="60"
          y1="60"
          x2={p.x}
          y2={p.y}
          stroke={C.orange}
          strokeWidth="5"
          strokeLinecap="round"
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - draw}
        />
      ))}
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={9 * draw} fill={i === 0 ? C.amber : C.ink} />
      ))}
      <circle cx="60" cy="60" r="17" fill={C.orange} />
    </svg>
  );
};

/** "Ronova Mesh" text wordmark with left-to-right reveal. progress 0..1. */
export const BrandReveal: React.FC<{progress: number; fontSize?: number; withMark?: boolean}> = ({
  progress,
  fontSize = 170,
  withMark = false,
}) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      gap: fontSize * 0.22,
      fontFamily: FONT,
      fontWeight: 700,
      fontSize,
      letterSpacing: -fontSize * 0.02,
      color: C.ink,
      whiteSpace: 'nowrap',
      clipPath: `inset(-20% ${(1 - progress) * 105}% -20% 0)`,
      transform: `translateY(${(1 - progress) * 22}px)`,
    }}
  >
    {withMark && <Mark size={fontSize * 0.9} draw={progress} />}
    <span>
      Ronova <span style={{color: C.orange}}>Mesh</span>
    </span>
  </div>
);

/** Three-icon end card trio: profile, friendship, network. */
export const EndCard: React.FC<{
  icons: [number, number, number]; // reveal 0..1 per icon
  converge: number; // 0..1 icons travel to centre
  mark: number; // 0..1 mark draw-on
  brand: number; // 0..1 wordmark reveal
  tagline: number; // 0..1 tagline reveal
}> = ({icons, converge, mark, brand, tagline}) => {
  const xs = [-400, 0, 400];
  const kinds = [UserIcon, UsersIcon, NetworkIcon];
  return (
    <div style={{position: 'absolute', inset: 0}}>
      {kinds.map((Ic, i) => {
        const x = xs[i] * (1 - converge);
        const op = icons[i] * (1 - converge);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: 960 - 90 + x,
              top: 360 - 90,
              width: 180,
              height: 180,
              borderRadius: '50%',
              background: C.white,
              border: `2px solid ${C.border}`,
              boxShadow: '0 12px 30px rgba(34,34,34,0.08)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: C.orange,
              opacity: op,
              transform: `scale(${(0.7 + 0.3 * icons[i]) * (1 - 0.4 * converge)}) translateY(${(1 - icons[i]) * 30}px)`,
            }}
          >
            <Ic size={92} sw={1.8} />
          </div>
        );
      })}
      <div style={{position: 'absolute', left: 0, right: 0, top: 265, display: 'flex', justifyContent: 'center', opacity: mark}}>
        <Mark size={190} draw={mark} />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 520, display: 'flex', justifyContent: 'center'}}>
        <BrandReveal progress={brand} />
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 740,
          textAlign: 'center',
          fontFamily: FONT,
          fontWeight: 600,
          fontSize: 84,
          color: C.muted,
          opacity: tagline,
          transform: `translateY(${(1 - tagline) * 24}px)`,
        }}
      >
        Stay Connected, Your Way.
      </div>
    </div>
  );
};

export {ProfileAvatar};
