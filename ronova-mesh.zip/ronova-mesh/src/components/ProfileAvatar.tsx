import React from 'react';
import {C} from '../lib/theme';

export type Tone = 'orange' | 'amber' | 'ink' | 'cream';

const GRAD: Record<Tone, string> = {
  orange: `linear-gradient(145deg, ${C.amber}, ${C.orange})`,
  amber: `linear-gradient(145deg, #FFE2B0, ${C.amber})`,
  ink: 'linear-gradient(145deg, #4A4640, #222222)',
  cream: `linear-gradient(145deg, #FFFFFF, #F3EDE2)`,
};

/**
 * Circular profile avatar (pure CSS + SVG glyph).
 * outline: 0..1 draws an orange outline ring; fill: 0..1 fades in the filled avatar.
 */
export const ProfileAvatar: React.FC<{
  size?: number;
  tone?: Tone;
  outline?: number;
  fill?: number;
  ring?: boolean;
  style?: React.CSSProperties;
}> = ({size = 100, tone = 'orange', outline = 1, fill = 1, ring = true, style}) => {
  const glyph = tone === 'cream' ? C.orange : 'rgba(255,255,255,0.95)';
  return (
    <div style={{position: 'relative', width: size, height: size, ...style}}>
      <div
        style={{
          position: 'absolute',
          inset: size * 0.05,
          borderRadius: '50%',
          overflow: 'hidden',
          background: GRAD[tone],
          opacity: fill,
          boxShadow: '0 6px 16px rgba(34,34,34,0.12)',
        }}
      >
        <svg width="100%" height="100%" viewBox="0 0 100 100">
          <circle cx="50" cy="38" r="17" fill={glyph} />
          <path d="M16 100 C18 70 36 61 50 61 C64 61 82 70 84 100 Z" fill={glyph} />
        </svg>
      </div>
      {ring && (
        <svg
          width={size}
          height={size}
          viewBox="0 0 100 100"
          style={{position: 'absolute', inset: 0, transform: 'rotate(-90deg)'}}
        >
          <circle
            cx="50"
            cy="50"
            r="48"
            fill="none"
            stroke={tone === 'ink' ? C.ink : C.orange}
            strokeWidth="2.6"
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - outline}
            opacity={tone === 'cream' ? 1 : 0.9}
          />
        </svg>
      )}
    </div>
  );
};
