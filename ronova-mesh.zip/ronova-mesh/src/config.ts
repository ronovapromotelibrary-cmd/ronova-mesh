import alignment from './data/alignment.json';

/** Single source of truth for composition settings. */
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

/** Duration of public/audio/voiceover.wav, verified with ffprobe (80.180042 s). */
export const AUDIO_DURATION_SECONDS = 80.180042;
/** Silent hold on the final brand card after the voice-over ends. Set to 0 to end with the audio. */
export const END_HOLD_SECONDS = 1.5;

export const AUDIO_FILE = 'audio/voiceover.wav';

/** frame = round(seconds * fps) — the one conversion rule used everywhere. */
export const toFrame = (seconds: number): number => Math.round(seconds * FPS);

export const AUDIO_FRAMES = Math.ceil(AUDIO_DURATION_SECONDS * FPS);
export const DURATION_FRAMES = AUDIO_FRAMES + toFrame(END_HOLD_SECONDS);

/** Length of the reveal that leads into every scene (frames). It plays inside the pause before the scene's first word. */
export const TRANSITION_FRAMES = 15;

/** Scene start frames, from audio-measured speech onsets (see src/data/alignment.json). */
export const SCENE_STARTS: number[] = alignment.sceneStartsAudioSeconds.map(toFrame);
