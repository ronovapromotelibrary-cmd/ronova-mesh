import transcript from '../data/transcript.json';
import alignment from '../data/alignment.json';
import {toFrame} from '../config';

export type Word = {word: string; start: number; end: number};

/** Original supplied transcript — never mutated. */
export const WORDS: readonly Word[] = transcript as Word[];

/**
 * When true, visual events use alignSeconds() (JSON time mapped onto the measured audio phrase
 * boundaries). When false, raw JSON timestamps are used unchanged.
 */
export const APPLY_AUDIO_ALIGNMENT = true;

type Seg = (typeof alignment.segments)[number];
const SEGS: readonly Seg[] = alignment.segments;

/** Piecewise-linear map from supplied-JSON seconds to estimated audio seconds. */
export const alignSeconds = (t: number): number => {
  if (!APPLY_AUDIO_ALIGNMENT) return t;
  for (const s of SEGS) {
    if (t >= s.jsonStart - 1e-6 && t <= s.jsonEnd + 1e-6) {
      const k = (t - s.jsonStart) / (s.jsonEnd - s.jsonStart);
      return s.audioStart + k * (s.audioEnd - s.audioStart);
    }
  }
  // Inside an un-aligned gap: keep the offset of the closest earlier segment.
  const prev = [...SEGS].reverse().find((s) => s.jsonEnd <= t) ?? SEGS[0];
  return t + (prev.audioEnd - prev.jsonEnd);
};

/** Find a transcript word by exact text, at or after `afterJsonSec` (disambiguates repeated words). */
export const findWord = (text: string, afterJsonSec = 0): Word => {
  const hit = WORDS.find((w) => w.word === text && w.start >= afterJsonSec - 1e-6);
  if (!hit) throw new Error(`Transcript word not found: "${text}" at/after ${afterJsonSec}s`);
  return hit;
};

/** Global frame at which a word starts. */
export const W = (text: string, afterJsonSec = 0): number =>
  toFrame(alignSeconds(findWord(text, afterJsonSec).start));

/** Global frame at which a word ends. */
export const WE = (text: string, afterJsonSec = 0): number =>
  toFrame(alignSeconds(findWord(text, afterJsonSec).end));

/** Frame from a raw JSON timestamp (aligned). */
export const T = (jsonSec: number): number => toFrame(alignSeconds(jsonSec));
