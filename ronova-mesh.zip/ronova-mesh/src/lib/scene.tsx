import React, {createContext, useContext} from 'react';
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {HEIGHT, WIDTH} from '../config';
import {C} from './theme';
import {easeInOut} from './anim';

const SceneFrom = createContext(0);

/** Global composition frame, usable from any component inside a <Scene>. */
export const useGF = (): number => {
  const local = useCurrentFrame();
  return local + useContext(SceneFrom);
};

/** Fixed 1920x1080 design stage, scaled to fit the composition size (layout stays responsive). */
export const Stage: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const s = Math.min(width / WIDTH, height / HEIGHT);
  return (
    <AbsoluteFill style={{backgroundColor: C.offWhite, alignItems: 'center', justifyContent: 'center'}}>
      <div
        style={{
          position: 'relative',
          width: WIDTH,
          height: HEIGHT,
          flexShrink: 0,
          overflow: 'hidden',
          transform: `scale(${s})`,
        }}
      >
        {children}
      </div>
    </AbsoluteFill>
  );
};

export type CamKey = {f: number; s: number; cx: number; cy: number};
const CamCtx = createContext({s: 1, cx: WIDTH / 2, cy: HEIGHT / 2});
export const useCamera = () => useContext(CamCtx);

/**
 * Camera: keyframes of (scale, focal point). The focal point (cx,cy) in stage units is kept at the
 * stage centre. All values are driven by the global frame; easing is in/out cubic per segment.
 */
export const Camera: React.FC<{keys: CamKey[]; children: React.ReactNode}> = ({keys, children}) => {
  const f = useGF();
  const frames = keys.map((k) => k.f);
  const opts = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const, easing: easeInOut};
  const s = interpolate(f, frames, keys.map((k) => k.s), opts);
  const cx = interpolate(f, frames, keys.map((k) => k.cx), opts);
  const cy = interpolate(f, frames, keys.map((k) => k.cy), opts);
  return (
    <CamCtx.Provider value={{s, cx, cy}}>
      <AbsoluteFill
        style={{
          transformOrigin: '0 0',
          transform: `translate(${WIDTH / 2 - cx * s}px, ${HEIGHT / 2 - cy * s}px) scale(${s})`,
        }}
      >
        {children}
      </AbsoluteFill>
    </CamCtx.Provider>
  );
};

/** Depth layer: depth 0 moves with the camera, depth 1 stays screen-fixed. Gives subtle parallax. */
export const Parallax: React.FC<{depth: number; children: React.ReactNode}> = ({depth, children}) => {
  const {cx, cy} = useCamera();
  return (
    <AbsoluteFill style={{transform: `translate(${(cx - WIDTH / 2) * depth}px, ${(cy - HEIGHT / 2) * depth}px)`}}>
      {children}
    </AbsoluteFill>
  );
};

/** Circular reveal that grows from the previous scene's focal object. */
export const SceneTransition: React.FC<{
  duration: number;
  origin: {x: number; y: number};
  children: React.ReactNode;
}> = ({duration, origin, children}) => {
  const local = useCurrentFrame();
  if (duration <= 0 || local >= duration) return <AbsoluteFill>{children}</AbsoluteFill>;
  const p = interpolate(local, [0, duration], [0, 1], {extrapolateRight: 'clamp', easing: easeInOut});
  const r = p * Math.hypot(WIDTH, HEIGHT);
  return (
    <AbsoluteFill style={{clipPath: `circle(${r}px at ${origin.x}px ${origin.y}px)`, opacity: Math.min(1, p * 2.2)}}>
      {children}
    </AbsoluteFill>
  );
};

/** One scene on the global timeline: Sequence + global-frame context + lead-in reveal. */
export const Scene: React.FC<{
  name: string;
  from: number;
  duration: number;
  transitionIn?: number;
  origin?: {x: number; y: number};
  children: React.ReactNode;
}> = ({name, from, duration, transitionIn = 0, origin = {x: WIDTH / 2, y: HEIGHT / 2}, children}) => (
  <Sequence name={name} from={from} durationInFrames={duration}>
    <SceneFrom.Provider value={from}>
      <SceneTransition duration={transitionIn} origin={origin}>
        {children}
      </SceneTransition>
    </SceneFrom.Provider>
  </Sequence>
);
