import {staticFile} from 'remotion';
import {loadFont as loadLocal} from '@remotion/fonts';
import {loadFont as loadBengali} from '@remotion/google-fonts/NotoSansBengali';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';

/**
 * Font strategy
 * -------------
 * false (default): fonts are fetched from Google Fonts by @remotion/google-fonts at render time
 *                  (needs network once; Remotion caches them while rendering).
 * true:            fonts are read from public/fonts/ (fully offline). Download these files from
 *                  https://fonts.google.com/noto/specimen/Noto+Sans+Bengali (SIL OFL 1.1) and Inter
 *                  (SIL OFL 1.1) and place them as listed in README.md.
 */
export const USE_LOCAL_FONTS = false;

const BN = 'Noto Sans Bengali';
const LATIN = 'Inter';

if (USE_LOCAL_FONTS) {
  const weights: Array<[string, string]> = [
    ['400', 'NotoSansBengali-Regular.ttf'],
    ['600', 'NotoSansBengali-SemiBold.ttf'],
    ['700', 'NotoSansBengali-Bold.ttf'],
  ];
  for (const [weight, file] of weights) {
    void loadLocal({family: BN, url: staticFile(`fonts/${file}`), weight});
  }
  const latin: Array<[string, string]> = [
    ['400', 'Inter-Regular.ttf'],
    ['600', 'Inter-SemiBold.ttf'],
    ['700', 'Inter-Bold.ttf'],
  ];
  for (const [weight, file] of latin) {
    void loadLocal({family: LATIN, url: staticFile(`fonts/${file}`), weight});
  }
} else {
  loadBengali('normal', {weights: ['400', '600', '700'], subsets: ['bengali', 'latin']});
  loadInter('normal', {weights: ['400', '600', '700'], subsets: ['latin']});
}

/** Latin glyphs come from Inter; Bengali glyphs fall through to Noto Sans Bengali (correct conjuncts). */
export const FONT = `"${LATIN}", "${BN}", system-ui, sans-serif`;
/** Bengali-first stack for Bengali words. */
export const FONT_BN = `"${BN}", "${LATIN}", system-ui, sans-serif`;
