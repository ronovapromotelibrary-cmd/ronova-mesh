import {Easing, interpolate, spring} from 'remotion';

export const easeOut = Easing.out(Easing.cubic);
export const easeInOut = Easing.inOut(Easing.cubic);

/** Eased 0..1 progress between `start` and `start + dur` (clamped). */
export const prog = (
  frame: number,
  start: number,
  dur: number,
  easing: (t: number) => number = easeOut,
): number =>
  interpolate(frame, [start, start + Math.max(1, dur)], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;

/** Low-overshoot spring (0..~1.02) starting at `start`. */
export const settle = (
  frame: number,
  fps: number,
  start: number,
  config: {damping?: number; stiffness?: number; mass?: number} = {damping: 22, stiffness: 130, mass: 1},
): number => spring({frame: Math.max(0, frame - start), fps, config});

/** Looping 0..1 phase, deterministic (depends only on frame). */
export const phase = (frame: number, start: number, period: number): number =>
  frame < start ? 0 : ((frame - start) % period) / period;

/** Quadratic bezier point; control point is the chord midpoint pushed along the normal by `bend`. */
export const arcPoint = (
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  bend: number,
  t: number,
): {x: number; y: number} => {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const cx = mx + (-dy / len) * bend;
  const cy = my + (dx / len) * bend;
  const u = 1 - t;
  return {
    x: u * u * x1 + 2 * u * t * cx + t * t * x2,
    y: u * u * y1 + 2 * u * t * cy + t * t * y2,
  };
};

export const arcPath = (x1: number, y1: number, x2: number, y2: number, bend: number): string => {
  const mx = (x1 + x2) / 2;
  const my = (y1 + y2) / 2;
  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.hypot(dx, dy) || 1;
  const cx = mx + (-dy / len) * bend;
  const cy = my + (dx / len) * bend;
  return `M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`;
};
