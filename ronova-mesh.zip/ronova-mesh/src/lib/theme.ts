export const C = {
  white: '#FFFFFF',
  offWhite: '#FAF8F4',
  orange: '#F28C28',
  amber: '#FFC46B',
  ink: '#222222',
  border: '#EDE8E0',
  muted: '#6B655C',
  amberSoft: '#FFF1DB',
};

export const SHADOW = '0 18px 40px rgba(34,34,34,0.08), 0 2px 6px rgba(34,34,34,0.05)';
export const SHADOW_SM = '0 8px 20px rgba(34,34,34,0.07), 0 1px 3px rgba(34,34,34,0.05)';
