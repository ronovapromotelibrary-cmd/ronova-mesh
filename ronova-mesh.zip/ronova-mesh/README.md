# Ronova Mesh — promo video (React + Remotion)

1920×1080, 30 fps, 2451 frames (80.18 s original Bengali voice-over + 1.5 s silent hold on the end card).
All motion is derived from `useCurrentFrame()`; there are no CSS transitions, timers or random values.

## Setup

```bash
npm install
npm run check      # verifies the WAV against src/config.ts, then type-checks
npm run studio     # Remotion Studio, open the "RonovaMeshPromo" composition
npm run render     # -> out/ronova-mesh-promo.mp4
```

Node 18+ is required. Dependencies are pinned to Remotion 4.0.528 (all `remotion` / `@remotion/*` packages must share one version).

## Change resolution / FPS

* Resolution: edit `WIDTH`/`HEIGHT` in `src/config.ts`. The design lives on a 1920×1080 stage that is scaled to fit (`Stage` in `src/lib/scene.tsx`), so other aspect ratios letterbox rather than break.
* Higher output without touching layout: `npm run render:4k` (render scale 2) or `npx remotion render RonovaMeshPromo out/x.mp4 --scale=2`.
* FPS: edit `FPS` in `src/config.ts`. Every frame number is produced by `toFrame(seconds) = round(seconds * FPS)`, so timing follows automatically.

## Replace the voice-over

1. Put the new file at `public/audio/voiceover.wav` (or change `AUDIO_FILE` in `src/config.ts`).
2. Set `AUDIO_DURATION_SECONDS` in `src/config.ts` (`ffprobe -v error -show_entries format=duration -of csv=p=0 public/audio/voiceover.wav`).
3. Re-measure pauses and update `src/data/alignment.json` (see below).
4. `node scripts/check-audio.mjs`

## Update the transcript / timing

* `src/data/transcript.json` is the supplied word-level JSON, unmodified. Scenes look words up by text (`W('সহজ', 25)` = first "সহজ" at or after 25 s of JSON time).
* The supplied JSON is evenly spaced inside each phrase, so it drifts from the real audio by up to ~1 s. `src/data/alignment.json` maps each JSON phrase onto the speech onset/offset measured in the audio:
  `ffmpeg -i public/audio/voiceover.wav -af silencedetect=noise=-33dB:d=0.12 -f null -`
  Aligned times are **estimates** (silence detection, not forced alignment). Set `APPLY_AUDIO_ALIGNMENT = false` in `src/lib/timing.ts` to use raw JSON times.
* Scene cut points are `sceneStartsAudioSeconds` in the same file.
* `node scripts/build-timing-map.mjs` regenerates `docs/timestamp-map.md`.

## Fonts

`src/lib/fonts.ts` loads Noto Sans Bengali (Bengali + conjuncts) and Inter (Latin) through `@remotion/google-fonts`; this needs network access once at render time. For fully offline renders set `USE_LOCAL_FONTS = true` and place these files in `public/fonts/` (SIL OFL 1.1, from fonts.google.com):

`NotoSansBengali-Regular.ttf`, `NotoSansBengali-SemiBold.ttf`, `NotoSansBengali-Bold.ttf`, `Inter-Regular.ttf`, `Inter-SemiBold.ttf`, `Inter-Bold.ttf`

## Assets, licences, assumptions

* No logo was supplied: the brand is a text wordmark plus an original geometric network mark (`Mark` in `src/components/Brand.tsx`).
* All icons are inline SVG (Feather-style strokes, MIT). No remote images. No official Google UI is imitated; the sign-in card uses a neutral key icon and "Continue with account".
* Names in the UI mockups (Maya, Rafi, Nila, Arif, Sara) are placeholders, not product claims.
* Bluetooth is shown as a conceptual illustration only and is always qualified on screen ("Internet not required*" + footnote), matching the script's condition.
* No music, SFX or synthetic speech is added.

## Layout

```
src/config.ts            fps, size, audio duration, scene start frames
src/lib/timing.ts        transcript lookup + alignment (W / WE / T helpers)
src/lib/anim.ts          easing, springs, arcs
src/lib/scene.tsx        Stage, Camera, Parallax, Scene, SceneTransition, useGF
src/components/          Background, PhoneMockup, ChatBubble, ProfileAvatar, Cards (ProfileCard,
                         FriendRequestCard), Network (NetworkNode, ConnectionLine), Connections
                         (BluetoothConnection, OnlineConnection), Brand (Mark, BrandReveal, EndCard)
src/scenes/              Scene1Hook ... Scene9EndCard
src/RonovaMeshPromo.tsx  orchestration + <Audio>
docs/                    PRODUCTION_NOTES.md, timestamp-map.md
```
