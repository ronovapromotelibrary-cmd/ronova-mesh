# Production notes

## A. Script analysis

**Arc:** hook (easier, smarter, closer) → communication is connection → introduce Ronova Mesh → modern messaging → Google sign-in and profile → friends and network → nearby Bluetooth (conditional) → online across distance → one brand: profile, friendship, network.

**Confirmed script claims:** modern messaging app; sign in with a Google account; personal profile; add contacts / find friends; friend requests; friendship network; Bluetooth-based communication with nearby friends *if* the required Bluetooth connection and app support are available, including without internet; internet-based online communication for distant friends; tagline "Stay Connected, Your Way."

**Not confirmed (so only illustrated):** how discovery, range, delivery or encryption work over Bluetooth; any real UI of the app; the Google sign-in screen.

**Findings about the supplied inputs**
1. The audio is 80.180 s (24 kHz mono WAV). The JSON ends at 80.00 s.
2. The JSON is evenly spaced inside each phrase and uses Bengali phonetic spellings for brand/English terms (e.g. "রনোভাব ম্যাশ"). Its 19 phrase groups match the 18 clearest pauses in the audio one-to-one, but absolute times drift up to ~1 s (e.g. JSON says scene 4 starts at 20.00 s, speech actually resumes at 20.77 s). JSON values are preserved; an alignment layer maps them onto measured phrase boundaries (estimates).
3. The script's last two lines ("Ronova Mesh-এর সঙ্গে যোগাযোগের নতুন অভিজ্ঞতা আবিষ্কার করুন." and "…আপনার নিজস্ব যোগাযোগের পথ.") have no counterpart in the JSON. Pause analysis shows only the tagline phrase after the "একটি আধুনিক অভিজ্ঞতায়" phrase, ending at 79.89 s. This is inferred from silence detection, not from listening; if those lines are in your audio they were not detected. No timestamps were invented for them.

## B. Visual direction
Palette #FFFFFF / #FAF8F4 / #F28C28 / #FFC46B / #222222 / #EDE8E0. Noto Sans Bengali + Inter. White cards with 2 px warm borders and soft shadows, orange used only for action and connection. Motion: out-cubic reveals, in/out-cubic camera and transitions, low-overshoot springs. Each scene reveals through a circular clip that grows from the focal object of the previous scene.

## C/E. Storyboard and camera plan

| # | Time (aligned) | Narration | Visual | Camera | Transition out |
|---|---|---|---|---|---|
| 1 | 0.00–4.14 | Easier, smarter, closer | Hub node grows; 3 bubbles + 3 avatars bloom on connection lines; keywords সহজ / স্মার্ট / কাছের highlight on their words | Push-in 1.00→1.08 (ends at centre) | Orange bubble flies to centre and enlarges into Scene 2's bubble |
| 2 | 4.14–15.13 | More than a message | Bubble shrinks to profile A, arcs to B on "পাঠানো"; line draws on "সংযুক্ত"; moment cards on "মুহূর্ত/ভাগ"; far nodes on "দূরত্বকে" | 1.12 → 1.00 (pan to 1000,560) → 0.88 pull-back | Avatars converge into one centre node |
| 3 | 15.13–20.77 | Introducing Ronova Mesh | Mark moves left, phone rises on "পরিচিত", wordmark reveals on "রনোভাব" | Static, then 1.0→2.5 push into phone screen | Push into screen |
| 4 | 20.77–29.75 | Modern messaging | Chat-list phone, floating bubbles, labels Simple / Comfortable / Smart on their words | 1.5→1.0 settle, parallax, 1.08 push-in, then 2.2 toward screen | Phone screen expands into sign-in card |
| 5 | 29.75–36.53 | Sign in, profile | Sign-in card, press feedback on "সাইন"; card swaps to profile; avatar outline draws then fills; name types | 1.00→1.08 | Avatar settles at centre as Scene 6 hub |
| 6 | 36.53–46.53 | Contacts, requests, network | Profile cards slide in; friend-request press + "Sent"; camera pulls back to two-ring network; pulses | 1.15 → 0.82 → 1.0 | Hero node morphs into the right phone |
| 7 | 46.53–60.10 | Nearby Bluetooth | Phones approach; Bluetooth badge draws on "ব্লুটুথ-ভিত্তিক"; arcs; "Nearby"; globe dims; "Internet not required*" + qualifier | 1.0 → 1.28 push → 1.08 pull-back | Phones separate, link stretches |
| 8 | 60.10–72.39 | Online across distance | Far phones, orange arc with globe badge and pulse; nearby friend with Bluetooth badge; "Online"/"Nearby" | Pan 1180→760, pull-back to 0.92 | Both paths converge into one hub node |
| 9 | 72.39–80.18 + 1.5 s | Profile, friendship, network, tagline | 3 icons on their words, lines converge, mark draws, wordmark on "রনোভাব", tagline on "স্টে" | Static | Final stable card |

On-screen text: সহজ / স্মার্ট / কাছের; Simple / Comfortable / Smart; Nearby; Internet not required* with its qualifying footnote; Online; Ronova Mesh; Modern messaging; Stay Connected, Your Way. No narration is subtitled.

## D. Timestamp-to-frame map
See `timestamp-map.md` (generated; all 186 words, original and aligned frames). Gaps: the 18 one-second gaps between phrase groups in the JSON are left as gaps; the last ~0.18 s of audio (80.00–80.18) is past the final JSON timestamp.

## H. Validation report (what was and was not verified)

Verified in this environment:
* Audio inspected with ffprobe/ffmpeg: 80.180042 s, 24 kHz mono; `node scripts/check-audio.mjs` passes.
* All 29 TS/TSX files parse without syntax errors (TypeScript `transpileModule`).
* Every `W()` word reference resolves to a real transcript word; all camera keyframe lists are strictly increasing; each scene's start frame coincides with the aligned first word of that scene.
* JSON file is unchanged (186 words, ordered, no overlaps).

NOT verified (sandbox has no network):
* `npm install`, a full type-check against Remotion's types, Studio preview and an actual render were **not run**. Package versions (Remotion 4.0.528 etc.) are taken from the installed skill metadata and were not confirmed against the registry.
* Bengali glyph rendering, final visual composition, and exact overlap/legibility have not been seen. The fonts load from Google Fonts at render time unless `USE_LOCAL_FONTS` is enabled.
* Expect to polish by eye in Studio after the first run (positions, timings and spacing were set numerically).
