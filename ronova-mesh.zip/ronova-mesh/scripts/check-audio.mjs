// Verifies public/audio/voiceover.wav against src/config.ts and the supplied transcript.
// Usage: node scripts/check-audio.mjs
import fs from 'node:fs';

const wav = fs.readFileSync('public/audio/voiceover.wav');
if (wav.toString('ascii', 0, 4) !== 'RIFF' || wav.toString('ascii', 8, 12) !== 'WAVE') {
  throw new Error('public/audio/voiceover.wav is not a RIFF/WAVE file (convert it to WAV or update AUDIO_FILE).');
}
let off = 12, rate = 0, ch = 0, bits = 0, dataBytes = 0;
while (off < wav.length - 8) {
  const id = wav.toString('ascii', off, off + 4);
  const size = wav.readUInt32LE(off + 4);
  if (id === 'fmt ') { ch = wav.readUInt16LE(off + 10); rate = wav.readUInt32LE(off + 12); bits = wav.readUInt16LE(off + 22); }
  if (id === 'data') { dataBytes = Math.min(size, wav.length - off - 8); break; }
  off += 8 + size + (size % 2);
}
const seconds = dataBytes / (rate * ch * (bits / 8));

const cfg = fs.readFileSync('src/config.ts', 'utf8');
const cfgAudio = Number(/AUDIO_DURATION_SECONDS\s*=\s*([0-9.]+)/.exec(cfg)[1]);
const fps = Number(/FPS\s*=\s*(\d+)/.exec(cfg)[1]);
const hold = Number(/END_HOLD_SECONDS\s*=\s*([0-9.]+)/.exec(cfg)[1]);

const words = JSON.parse(fs.readFileSync('src/data/transcript.json', 'utf8'));
let ordered = true, overlap = 0;
for (let i = 1; i < words.length; i++) {
  if (words[i].start < words[i - 1].start) ordered = false;
  if (words[i].start < words[i - 1].end - 1e-9) overlap++;
}
const last = words[words.length - 1];

console.log(`WAV: ${rate} Hz, ${ch} ch, ${bits}-bit, ${seconds.toFixed(3)} s`);
console.log(`config AUDIO_DURATION_SECONDS = ${cfgAudio}  (${Math.abs(seconds - cfgAudio) < 0.01 ? 'MATCH' : 'MISMATCH - update src/config.ts'})`);
console.log(`composition frames = ${Math.ceil(cfgAudio * fps) + Math.round(hold * fps)} @ ${fps} fps (audio ${Math.ceil(cfgAudio * fps)} + hold ${Math.round(hold * fps)})`);
console.log(`transcript: ${words.length} words, ordered=${ordered}, overlaps=${overlap}, last end=${last.end}s`);
console.log(`audio extends ${(seconds - last.end).toFixed(3)} s past the last transcript timestamp`);
if (Math.abs(seconds - cfgAudio) >= 0.01) process.exit(1);
