// Generates docs/timestamp-map.md from the untouched transcript + alignment anchors.
// Usage: node scripts/build-timing-map.mjs
import fs from 'node:fs';

const FPS = Number(/FPS\s*=\s*(\d+)/.exec(fs.readFileSync('src/config.ts', 'utf8'))[1]);
const words = JSON.parse(fs.readFileSync('src/data/transcript.json', 'utf8'));
const al = JSON.parse(fs.readFileSync('src/data/alignment.json', 'utf8'));
const toFrame = (s) => Math.round(s * FPS);
const align = (t) => {
  for (const s of al.segments) {
    if (t >= s.jsonStart - 1e-6 && t <= s.jsonEnd + 1e-6) {
      return s.audioStart + ((t - s.jsonStart) / (s.jsonEnd - s.jsonStart)) * (s.audioEnd - s.audioStart);
    }
  }
  throw new Error('unaligned ' + t);
};

let md = `# Timestamp-to-frame map\n\nFPS = ${FPS}. Rule: \`frame = round(seconds * fps)\`.\n\n`;
md += `## Segments (JSON gaps matched to measured pauses in the audio)\n\n| # | JSON start-end (s) | Audio start-end (s, estimated) | JSON frames | Aligned frames |\n|---|---|---|---|---|\n`;
for (const s of al.segments) {
  md += `| ${s.id} | ${s.jsonStart.toFixed(2)}-${s.jsonEnd.toFixed(2)} | ${s.audioStart.toFixed(2)}-${s.audioEnd.toFixed(2)} | ${toFrame(s.jsonStart)}-${toFrame(s.jsonEnd)} | ${toFrame(s.audioStart)}-${toFrame(s.audioEnd)} |\n`;
}
md += `\n## Scene boundaries (audio-measured speech onsets)\n\n| Scene | Start (s) | Start frame | Mount frame (start - 15) |\n|---|---|---|---|\n`;
al.sceneStartsAudioSeconds.forEach((t, i) => {
  md += `| ${i + 1} | ${t.toFixed(2)} | ${toFrame(t)} | ${i === 0 ? 0 : toFrame(t) - 15} |\n`;
});
md += `\n## Words (original JSON values are unchanged; aligned columns are ESTIMATES)\n\n| # | Word | JSON start | JSON end | JSON start frame | Aligned start (s, est.) | Aligned start frame | Aligned end frame |\n|---|---|---|---|---|---|---|---|\n`;
words.forEach((w, i) => {
  md += `| ${i + 1} | ${w.word} | ${w.start.toFixed(2)} | ${w.end.toFixed(2)} | ${toFrame(w.start)} | ${align(w.start).toFixed(2)} | ${toFrame(align(w.start))} | ${toFrame(align(w.end))} |\n`;
});
fs.mkdirSync('docs', {recursive: true});
fs.writeFileSync('docs/timestamp-map.md', md);
console.log('wrote docs/timestamp-map.md');
